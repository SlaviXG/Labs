#pragma once
#include "Snake.h"

bool FrameISApple(Apple& apple, Snake& snake);
void SetPositionApple(Apple& apple, Snake& snake);
bool EatApple(Apple& apple, Snake& snake);
